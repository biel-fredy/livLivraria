import { Cliente } from 'core/types/cliente';
import DeleteButton from '../ActionButtons/DeleteButton';
import EditButton from '../ActionButtons/EditButton';
import CartoesButton from './CartoesButton';
import EnderecosButton from './EnderecosButton';
import './styles.scss';
import TransacoesButton from './TransacoesButton';

const ActionButtonsAdmin = () => {
  return (
    <div>
      <EditButton />
      <DeleteButton />
      <CartoesButton />
      <EnderecosButton idCliente={1} />
      <TransacoesButton />
    </div>
  );
};

export default ActionButtonsAdmin;
