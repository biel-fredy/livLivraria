import './styles.scss';

const ButtonIcon = () => (
    <button className="btn-primary btn-icon">
        <h5>Entrar</h5>
    </button>
);

export default ButtonIcon;