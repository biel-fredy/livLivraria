const Form = () => {
  return <h1>Form</h1>;
};

export default Form;
