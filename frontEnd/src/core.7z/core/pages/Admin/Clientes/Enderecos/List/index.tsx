import axios, { AxiosRequestConfig } from 'axios';
import { Endereco } from 'core/types/endereco';
import { BASE_URL } from 'core/utils/requests';
import { useState, useEffect } from 'react';
import { Button, Table } from 'react-bootstrap';

type Props = {
  clienteId: string;
};

const List = ({ clienteId }: Props) => {
  const [enderecos, setEnderecos] = useState<Endereco[]>();

  useEffect(() => {
    const params: AxiosRequestConfig = {
      method: 'GET',
      url: `${BASE_URL}/enderecos/cliente/${clienteId}`,
    };

    axios(params).then((response) => {
      setEnderecos(response.data);
    });
  }, [clienteId]);

  return (
    <div className="container table-container border-radius-20">
      <div className="button-add-item">
        <Button href="/clientes/adicionar">Adicionar Endereço</Button>
      </div>
      <Table className="bg-white">
        <thead>
          <tr>
            <th>CEP</th>
            <th>Logradouro</th>
            <th>Tipo Endereço</th>
            <th colSpan={4}>Ações</th>
          </tr>
        </thead>
        <tbody>
          {enderecos?.map((endereco) => (
            <tr>
              <td>{endereco.cep}</td>
              <td>{endereco.logradouro}</td>
              <td>{endereco.tipoEndereco}</td>
              <td colSpan={4}></td>
            </tr>
          ))}
        </tbody>
      </Table>
    </div>
  );
};

export default List;
