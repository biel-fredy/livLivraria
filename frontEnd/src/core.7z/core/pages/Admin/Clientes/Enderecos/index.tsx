import { Route, Switch } from 'react-router-dom';
import Form from './Form';
import List from './List';
import './styles.scss';

const Enderecos = () => {
  return (
    <Switch>
      <Route path="/admin/clientes/:clienteId/enderecos" exact>
        <List clienteId={'1'} />
      </Route>
      <Route path="/admin/clientes/:clienteId/enderecos/:enderecoId" exact>
        <Form />
      </Route>
    </Switch>
  );
};

export default Enderecos;
