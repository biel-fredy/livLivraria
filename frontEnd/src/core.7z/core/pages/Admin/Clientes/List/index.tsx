import axios, { AxiosRequestConfig } from 'axios';
import ActionButtonsAdmin from 'core/components/ActionButtonsAdmin';
import { Cliente } from 'core/types/cliente';
import { BASE_URL } from 'core/utils/requests';
import { useState, useEffect } from 'react';
import { Button, Table } from 'react-bootstrap';

const List = () => {
  const [clientes, setClientes] = useState<Cliente[]>();

  useEffect(() => {
    const params: AxiosRequestConfig = {
      method: 'GET',
      url: `${BASE_URL}/clientes`,
    };

    axios(params).then((response) => {
      setClientes(response.data);
    });
  }, []);

  return (
    <div className="product-crud-container">
      <div className="container table-container border-radius-20">
        <div className="button-add-item">
          <Button href="/clientes/create">Adicionar Cliente</Button>
        </div>
        <Table className="bg-white">
          <thead>
            <tr>
              <th>Código Cliente</th>
              <th>Nome Cliente</th>
              <th>Status</th>
              <th colSpan={4}>Ações</th>
            </tr>
          </thead>
          <tbody>
            {clientes?.map((cliente) => (
              <tr>
                <td>{cliente.id}</td>
                <td>{cliente.nome}</td>
                <td>{cliente.status}</td>
                <td colSpan={4}>
                  <ActionButtonsAdmin />
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      </div>
    </div>
  );
};

export default List;
