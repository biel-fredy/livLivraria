import { Route, Switch } from 'react-router-dom';
import FormCliente from './FormCliente';
import List from './List';
import './styles.scss';

const Clientes = () => {
  return (
    <Switch>
      <Route path="/admin/clientes" exact>
        <FormCliente />
      </Route>
      <Route path="/admin/clientes/gabriel">
        <FormCliente />
      </Route>
    </Switch>
  );
};

export default Clientes;
