import { Switch, Route } from 'react-router-dom';
import Clientes from './Clientes';
import Navbar from './Navbar';

import './styles.scss';

const Admin = () => {
  return (
    <div className="admin-container">
      <Navbar />
      <div className="admin-content">
        <Switch>
          <Route path="/admin/livros">
            <h1>Livros CRUD</h1>
          </Route>
          <Route path="/admin/clientes" exact>
            <Clientes />
          </Route>
        </Switch>
      </div>
    </div>
  );
};
export default Admin;
