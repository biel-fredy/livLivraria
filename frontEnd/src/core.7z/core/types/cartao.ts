export type Cartao = {
  id: number;
};
