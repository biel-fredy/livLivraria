import { Estado } from './estado';

export type Cidade = {
  descricao: string;
  estado: Estado;
};
