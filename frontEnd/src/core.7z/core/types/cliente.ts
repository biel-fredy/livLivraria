import { Documento } from './documento';
import { Endereco } from './endereco';
import { Pedido } from './pedido';

export type Cliente = {
  id: number;
  nome: string;
  dataCadastro: string;
  status: boolean;
  genero: string;
  dataNascimento: string;
  cpf: string;
  email: string;
  ranking: number;
  enderecos: Endereco[];
  documentos: Documento[];
  pedidos: Pedido[];
};
