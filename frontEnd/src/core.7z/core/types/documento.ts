import { Cliente } from './cliente';

export type Documento = {
  id: number;
  codigo: string;
  validade: string;
  cliente: Cliente;
  dataCadastro: string;
};
