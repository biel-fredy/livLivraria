import { Cidade } from "./cidade";
import { Cliente } from "./cliente";
import { TipoEndereco } from "./tipoendereco";

export type Endereco = {
  logradouro: string;
  cep: string;
  complemento: string;
  tipoEndereco: TipoEndereco;
  cliente: Cliente;
  cidade: Cidade;
};
