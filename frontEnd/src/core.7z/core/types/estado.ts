export type Estado = {
  descricao: string;
};
