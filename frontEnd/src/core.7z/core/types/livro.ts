export type Livro = {
  id: number;
  preco: number;
  nome: string;
};
