export type Pedido = {
  id: number;
};
