export type TipoDocumento = {
    id: number;
    dataCadastro: string;
    descricao: string;
    nome: string;
}