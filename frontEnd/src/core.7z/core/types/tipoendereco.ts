export type TipoEndereco = {
  id: number;
};
